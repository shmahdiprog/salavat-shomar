import { useState } from "react";

function SalavatShomar() {
  const [salavat, setSalavat] = useState<number>(0)
  return (
    <>
      <h2>امام‌زمان علیه‌السلام در توقیع خود به اسحاق‌بن یعقوب می‌فرمایند</h2>
      <h1>وَ أَکْثِرُوا الدُّعَاءَ بِتَعْجِیلِ الْفَرَجِ فَإِنَّ ذَلِکَ فَرَجُکُمْ</h1>
      <h2>شما {salavat} صلوات برای تعجیل ظهور امام‌زمان علیه‌السلام فرستاده‌اید</h2>
      <div id="buttons">
        <button id="plus" className="button" onClick={() => setSalavat(salavat + 1)}>صلوات فرستادن</button>
        <button id="zero" className="button" onClick={() => setSalavat(0)}>شروع مجدد</button>
      </div>
      
    </>
  );
}

export default SalavatShomar;